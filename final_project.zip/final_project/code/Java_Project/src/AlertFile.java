import java.io.*;

public class AlertFile {

    public static void WriteAlert(String content, String type) {
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("/home/seed/Desktop/final_project/alert/"
                    + type + "_alert.txt", true)));
            out.write(content + "\r\n");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
