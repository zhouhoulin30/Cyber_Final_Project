import java.io.File;
import java.util.Scanner;

public class FinalProject {
    public static void main(String[] args) {
            PCAPService pcapService = new PCAPService();
            System.out.println("----------Attack: csrf, reserve_shell, SQL_Injection, xss, tcp_reset----------");
            System.out.print("请选择要检测的攻击类型: ");
            Scanner input = new Scanner(System.in);
            String name = input.next();
            File pcapFile = new File("/home/seed/Desktop/final_project/traffic/"+name+".pcap");
            pcapService.parsePcap(pcapFile);
    }
}
