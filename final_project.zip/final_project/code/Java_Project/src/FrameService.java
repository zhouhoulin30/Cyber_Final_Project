
import java.util.Arrays;

public class FrameService {

    // 目前仅仅解析Linux cooked capture的帧
    /*
     *     | 2-bytes | 2-bytes | 2-bytes | 6-bytes src | 2-bytes | 2-bytes protocol type |
     *     |-----------------------------------  16bytes  -------------------------------|
     *     IPv4 中type为采用 0x0800
     */
    public FrameHeader parseFrameHeader(byte[] frameHeaderBuffer) {
        FrameHeader frameHeader = new FrameHeader();
        byte[] protocolBuffer = Arrays.copyOfRange(frameHeaderBuffer, 14, 16);

        int protocol = DataUtils.byteArray2Int(protocolBuffer, 2);
        frameHeader.setProtocol(protocol);
        return frameHeader;
    }
}
