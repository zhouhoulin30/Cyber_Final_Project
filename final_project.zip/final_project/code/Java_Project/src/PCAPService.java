import jdk.nashorn.internal.objects.Global;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;


public class PCAPService {

    private FrameService frameService = new FrameService();
    private IPService ipService = new IPService();
    private TCPService tcpService = new TCPService();
    private String Alert = new String();
    private int flag = 0;
    private ArrayList<Integer> TtlList = new ArrayList<Integer>();

    public void parsePcap(File pcapFile) {

        // pcap global header: 24 bytes
        byte[] globalHeaderBuffer = new byte[24];
        // pcap packet header: 16 bytes
        byte[] packetHeaderBuffer = new byte[16];
        byte[] packetDataBuffer;

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(pcapFile);
            if(fis.read(globalHeaderBuffer) != 24) {
                System.out.println("The Pcap file is broken!");
                return;
            }

            // 解析 Global Header
            GlobalHeader globalHeader = parseGlobalHeader(globalHeaderBuffer);
            //System.out.println(globalHeader.getLinkType());

            while (fis.read(packetHeaderBuffer) > 0) {
                // 解析 Packet Header
                PacketHeader packetHeader = parsePacketHeader(packetHeaderBuffer);
                packetDataBuffer = new byte[packetHeader.getCapLen()];
                if (fis.read(packetDataBuffer) != packetHeader.getCapLen()) {
                    System.out.println("The Pcap file is broken!");
                    return;
                }
                Alert = Integer.toString(packetHeader.getTimeS()) + ' ' + Integer.toString(packetHeader.getTimeMs())
                        + ' ' + Integer.toString(packetHeader.getTimeS()) + ' ' + Integer.toString(packetHeader.getTimeMs());
                // 解析Packet Data
                parsePacketData(packetDataBuffer);
            }
            if(flag==0)
                System.out.println("Safe!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     *  解析Global Header
     */
    private GlobalHeader parseGlobalHeader(byte[] globalHeaderBuffer) {
        GlobalHeader globalHeader = new GlobalHeader();

        byte[] magicBuffer = Arrays.copyOfRange(globalHeaderBuffer, 0, 4);
        byte[] linkTypeBuffer = Arrays.copyOfRange(globalHeaderBuffer, 20, 24);

        int magic = DataUtils.byteArray2Int(magicBuffer, 4);

        DataUtils.reverseByteArray(linkTypeBuffer);
        int linkType = DataUtils.byteArray2Int(linkTypeBuffer, 4);
        globalHeader.setMagic(magic);
        globalHeader.setLinkType(linkType);

        return globalHeader;
    }
    /**
     *  解析Packet Header
     */
    private PacketHeader parsePacketHeader(byte[] dataHeaderBuffer){

        byte[] timeSBuffer = Arrays.copyOfRange(dataHeaderBuffer, 0, 4);
        byte[] timeMsBuffer = Arrays.copyOfRange(dataHeaderBuffer, 4, 8);
        byte[] capLenBuffer = Arrays.copyOfRange(dataHeaderBuffer, 8, 12);
        byte[] lenBuffer = Arrays.copyOfRange(dataHeaderBuffer, 12, 16);

        PacketHeader packetHeader = new PacketHeader();

        DataUtils.reverseByteArray(timeSBuffer);
        DataUtils.reverseByteArray(timeMsBuffer);
        DataUtils.reverseByteArray(capLenBuffer);
        DataUtils.reverseByteArray(lenBuffer);

        int timeS = DataUtils.byteArray2Int(timeSBuffer, 4);
        int timeMs = DataUtils.byteArray2Int(timeMsBuffer, 4);
        int capLen = DataUtils.byteArray2Int(capLenBuffer, 4);
        int len = DataUtils.byteArray2Int(lenBuffer, 4);

        packetHeader.setTimeS(timeS);
        packetHeader.setTimeMs(timeMs);
        packetHeader.setCapLen(capLen);
        packetHeader.setLen(len);

        return packetHeader;
    }
    /**
     *  解析PacketData
     */
    private void parsePacketData(byte[] packetDataBuffer) {

        byte[] framHeaderBuffer = Arrays.copyOfRange(packetDataBuffer, 0, 16);
        FrameHeader frameHeader = frameService.parseFrameHeader(framHeaderBuffer);
        //System.out.println(frameHeader.getProtocol());

        if (frameHeader.getProtocol() != FrameHeader.PROTOCOL_IP) {
            //System.out.println(frameHeader.getProtocol());
            return;
        }

        // ip包首都的第一个字节的前4位是版本 后四位是首部的长度（单位4字节）
        // expect:0x45--->4:ipv4  5->20字节 69
        // 版本固定是64所以减去64 再 *4就是长度
        int ipHeaderLen = (packetDataBuffer[16] - 64 ) * 4;
        byte[] ipHeaderBuffer = Arrays.copyOfRange(packetDataBuffer, 16, 16 + ipHeaderLen);

        IPHeader ipHeader = ipService.parseIPHeader(ipHeaderBuffer);

        if (ipHeader.getProtocol() != IPHeader.PROTOCOL_TCP) {
            //System.out.println("This packet is not TCP segment");
            return;
        }

        // 数据偏移位于TCP字段第13个字节（0开始），占高4位，单位是4字节
        //int tcpHeaderLen  = ((packetDataBuffer[16+ipHeaderLen+12] & 0xf0) >> 4) * 4;

        byte[] tcpHeaderBuffer = Arrays.copyOfRange(packetDataBuffer, 16 + ipHeaderLen, 16 + ipHeaderLen + 14);

        TCPHeader tcpHeader = tcpService.parseTCPHeader(tcpHeaderBuffer);

        byte[] PayloadData = Arrays.copyOfRange(packetDataBuffer,16 + ipHeaderLen + 14,packetDataBuffer.length);
        int DataLen = PayloadData.length;
        String StrPayloadData = new String();
        if(DataLen != 0) {
            for(int i=0; i<DataLen; i++) {
                if(PayloadData[i] < 0)
                    StrPayloadData = StrPayloadData + (char)(PayloadData[i]+256);
                else
                    StrPayloadData = StrPayloadData + (char)(PayloadData[i]);
            }
        }
        /**
         * 基于流的检测
         */
        if(TtlList.size()==0) {
            TtlList.add(ipHeader.getTtl());
        }
        else {
            if( Math.abs(ipHeader.getTtl()-TtlList.get(0))>5 ) {
                if(tcpHeader.getRstFlag()==4) {
                    String TCP_Reset_Detect = Integer.toString(ipHeader.getSrcIP()) + ' ' + Integer.toString(tcpHeader.getSrcPort())
                            + ' ' + Integer.toString(ipHeader.getDstIP()) + ' ' + Integer.toString(tcpHeader.getDstPort()) + ' ' + "TCP_Reset";
                    Alert+=TCP_Reset_Detect;
                    flag = 1;
                    System.out.println(Alert);
                    AlertFile.WriteAlert(Alert, "TCP_Reset");
                }
            }
            TtlList.set(0, ipHeader.getTtl());
        }
        //System.out.println(StrPayloadData);
        /**
         * 基于报文负载特征的检测
          */
        if(StrPayloadData.contains("POST")) {
            if(StrPayloadData.contains("<script>alert(\"XSS\");</script>")) {
                String XSS_Detect = Integer.toString(ipHeader.getSrcIP()) + ' ' + Integer.toString(tcpHeader.getSrcPort())
                        + ' ' + Integer.toString(ipHeader.getDstIP()) + ' ' + Integer.toString(tcpHeader.getDstPort()) + ' ' + "XSS";
                Alert+=XSS_Detect;
                flag = 1;
                System.out.println(Alert);
                AlertFile.WriteAlert(Alert, "XSS");
            }
        }
        else if (StrPayloadData.contains("GET")) {
            // decode('#) --> %27%23
            if(StrPayloadData.contains("%27%23")) {
                String SQL_Detect = Integer.toString(ipHeader.getSrcIP()) + ' ' + Integer.toString(tcpHeader.getSrcPort())
                        + ' ' + Integer.toString(ipHeader.getDstIP()) + ' ' + Integer.toString(tcpHeader.getDstPort()) + ' ' + "SQL_Injection";
                Alert+=SQL_Detect;
                flag = 1;
                System.out.println(Alert);
                AlertFile.WriteAlert(Alert, "SQL_Injection");
            }
            else if (StrPayloadData.contains("addfriend.html")) {
                String CSRF_Detect = Integer.toString(ipHeader.getSrcIP()) + ' ' + Integer.toString(tcpHeader.getSrcPort())
                        + ' ' + Integer.toString(ipHeader.getDstIP()) + ' ' + Integer.toString(tcpHeader.getDstPort()) + ' ' + "CSRF";
                Alert+=CSRF_Detect;
                flag = 1;
                System.out.println(Alert);
                AlertFile.WriteAlert(Alert, "CSRF");
            }
        }
        else if (StrPayloadData.contains("0<&1 2>&1")) {
            String Reserve_Shell_Detect = Integer.toString(ipHeader.getSrcIP()) + ' ' + Integer.toString(tcpHeader.getSrcPort())
                    + ' ' + Integer.toString(ipHeader.getDstIP()) + ' ' + Integer.toString(tcpHeader.getDstPort()) + ' ' + "Reserve_Shell";
            Alert+=Reserve_Shell_Detect;
            flag = 1;
            System.out.println(Alert);
            AlertFile.WriteAlert(Alert, "Reserve_Shell");
        }
    }
}